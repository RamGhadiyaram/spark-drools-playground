package com.vz.housekeep

import java.io.File
import java.sql.{Connection, ResultSet, Statement}

import com.vz.housekeep.PODOps.{createSymLinks, logger, podName}
import com.vz.util.Utility._
import org.apache.commons.io.FileUtils

case object CreateCommand {
  def apply(args: Array[String]) {
    logger.info(getCurrentMethodName +
      """  * PODCreator.
        |  * 1) Lookup POD (hive schema) is present in the database.
        |  *  This schema was populated by NEO 4J
        |  2) Check whether tables are persent in databases which was selected
        |  * 2) Create a POD folder structure and symlinks for example
        |  * <pre>
        |  * ~/parking1/test/dwh_cicdpersist/
        |  * └── script
        |  * ├── client.truststore -> /home/hadoop/client.truststore
        |  * └── fairscheduler.xml -> /home/hadoop/fairscheduler.xml
        |  *   </pre>
        |  *""")
    val podPath: String = Option(args(2)).getOrElse(s"/home/hadoop/parking/") + "/" + podName
    val podPathWithScript = s"$podPath/script"
    logger.info("PODNAME " + podName + " PODPATH " + podPathWithScript)
    var conn: Connection = null

    try {
      conn = accessHiveMetaStoreGetConnection
      val st: Statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)

      val queryForDatabases = s"SELECT NAME FROM hive.DBS Where NAME = '$podName'"

      val resultForDataBases: ResultSet = st.executeQuery(queryForDatabases)
      DBTablePrinter.printResultSet(resultForDataBases)


      resultForDataBases.beforeFirst
      if (resultForDataBases.next()) {
        logger.info(s"POD Path $podName  EXIST... ")
        // second level of verification
        val queryForTables =
          s"""
             | SELECT TBL_NAME,TBL_TYPE FROM hive.TBLS t
             | JOIN
             | hive.DBS d  ON t.DB_ID = d.DB_ID
             | WHERE d.NAME = '$podName'
             | and t.TBL_NAME in ('fs_site','fs_parking_group')
        """.stripMargin
        logger.info(queryForTables)
        val resultForTables: ResultSet = st.executeQuery(queryForTables)
        DBTablePrinter.printResultSet(resultForTables)
        resultForTables.beforeFirst()
        if (resultForTables.next()) {
          // PoD already provisioned in Spark cluster. Hence skipping further configuration process.
          throw new RuntimeException(s"POD/schema $podName  Already exist in Path " +
            s" $podPath basic Tables \n FS_SITE \n FS_PARKING_GROUP were  found ")
        } // tables check

      } // database check
    } catch {
      case ex: Exception =>
        logger.error(getCurrentMethodName + ex.getCause)
    }
    finally {
      if (conn != null) conn.close
    }
    if (!new File(podPath).exists()) {
      logger.info(s"POD Path $podPath does NOT exist hence creating one ... $podPath/$podName ")
      FileUtils.forceMkdir(new File(podPathWithScript))
    }
    createSymLinks(podName, podPathWithScript)
    val command = s"tree ${podPath}/$podName "
    walkThroughFSTrees(command)
   /* val commandProcess = s"ps -aef |  grep -i $podName"
    walkThroughFSTrees(commandProcess)*/
    //val killcommandProcess = s"pkill -f  | grep $podName"
   //walkThroughFSTrees(killcommandProcess)
    executeProcessScripts(s"$podPath/script")
  }
}