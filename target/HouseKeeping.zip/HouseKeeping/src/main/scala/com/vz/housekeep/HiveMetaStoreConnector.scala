package com.vz.housekeep

import java.util

import com.google.common.base.Joiner
import org.apache.hadoop.hive.conf.HiveConf
import org.apache.hadoop.hive.metastore.api.MetaException
import org.apache.thrift.TException
import org.joda.time.DateTime

/**
  * HiveMetaStoreConnector : Connects to hive metastore via hive-site.xml and
  * list all the partition and column information and is further extendable.
  *
  * @author Ram Ghadiyaram
  * @param hiveConf
  */
class HiveMetaStoreConnector(hiveConf: HiveConf) {

  import org.apache.hadoop.hive.metastore.HiveMetaStoreClient

  var hiveMetaStoreClient: HiveMetaStoreClient =
    new HiveMetaStoreClient(hiveConf)

  /**
    * getAllPartitionInfo.
    *
    * @param dbName String
    * @return String
    */
  def getAllPartitionInfo(dbName: String): String = {
    var res = new util.ArrayList[String]()
    try {
      val tableList = hiveMetaStoreClient.getAllTables(dbName)
      import scala.collection.JavaConversions._
      for (tableName <- tableList) {
        res.addAll(getTablePartitionInformation(dbName, tableName))
      }
    } catch {
      case e: MetaException =>
        e.printStackTrace()
        println("getAllTableStatistic error")
        println(e.toString)
        System.exit(-100)
    }
    Joiner.on("\n").join(res)
  }

  /**
    * getTablePartitionInformation.
    *
    * @param dbName    String
    * @param tableName String
    * @return util.ArrayList[String]
    */
  def getTablePartitionInformation(dbName: String, tableName: String): util.ArrayList[String] = {
    val partitionsInfo = new util.ArrayList[String]()
    try {
      val partitionNames = hiveMetaStoreClient.listPartitionNames(dbName, tableName, 10000.toShort)
      val partitions = hiveMetaStoreClient.listPartitions(dbName, tableName, 10000.toShort)
      import scala.collection.JavaConversions._
      for (partition <- partitions) {
        val sb = new StringBuffer
        sb.append(tableName)
        sb.append("\t")
        val partitionValues = partition.getValues
        if (partitionValues.size < 4) {
          val size = partitionValues.size
          var j = 0
          while (
            j < 4 - size
          ) {
            partitionValues.add("null")

            {
              j += 1;
              j - 1
            }
          }
        }
        sb.append(Joiner.on("\t").join(partitionValues))
        sb.append("\t")
        val createDate = new DateTime(partition.getCreateTime.toLong * 1000)
        sb.append(createDate.toString("yyyy-MM-dd HH:mm:ss"))
        partitionsInfo.add(sb.toString)
      }
    } catch {
      case e: TException =>
        e.printStackTrace()
        val res = new util.ArrayList[String]()
        res.add("error for request on" + tableName)
        return res
    }
    partitionsInfo
  }

  /**
    * getAllTableStatistic.
    *
    * @param dbName String
    * @return String
    */
  def getAllTableStatistic(dbName: String): String = {
    val res = new util.ArrayList[String]()
    try {
      val tableList = hiveMetaStoreClient.getAllTables(dbName)
      import scala.collection.JavaConversions._
      for (tableName <- tableList) {
        res.addAll(getTableColumnsInformation(dbName, tableName))
      }
    } catch {
      case e: MetaException =>
        e.printStackTrace()
        println("getAllTableStatistic error")
        println(e.toString)
        System.exit(-100)
    }
    Joiner.on("\n").join(res)
  }

  /**
    * getTableColumnsInformation.
    *
    * @param dbName    String
    * @param tableName String
    * @return util.List[String]
    */
  def getTableColumnsInformation(dbName: String, tableName: String): util.List[String] = try {
    val fields = hiveMetaStoreClient.getFields(dbName, tableName)
    val infs = new util.ArrayList[String]()
    var cnt = 0
    import scala.collection.JavaConversions._
    for (fs <- fields) {
      val sb = new StringBuffer
      sb.append(tableName)
      sb.append("\t")
      sb.append(cnt)
      sb.append("\t")
      cnt += 1
      sb.append(fs.getName)
      sb.append("\t")
      sb.append(fs.getType)
      sb.append("\t")
      sb.append(fs.getComment)
      infs.add(sb.toString)
    }
    infs
  } catch {
    case e: TException =>
      e.printStackTrace()
      println("getTableColumnsInformation error")
      println(e.toString)
      System.exit(-100)
      null
  }
}