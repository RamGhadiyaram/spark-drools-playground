package com.vz.housekeep

import java.io.File

import com.vz.housekeep.HiveJDBCWatcher.logger
import com.vz.util.Utility
import com.vz.util.Utility.executeCommand
import org.apache.commons.io.FileUtils

/**
  * HiveMetaStoreConnectorTest
  *
  * @author Ram Ghadiyaram
  */
object HiveMetaStoreConnectorTest extends App {
  val (conn, conf) = Utility.accessHiveMetaStoreGetRef

  val hiveMetaStoreConnector = new HiveMetaStoreConnector(conf);
  var db: String = if (args.length > 0) args(0).toString else "dwh_qa310"
  println(db)
  if (hiveMetaStoreConnector != null) {
    var result1 = hiveMetaStoreConnector.getAllPartitionInfo(db);
    logger.info("this.getClass().getClassLoader().getResource(\"\").getPath()" + new File(this.getClass().getClassLoader().getResource("").getPath()).getParentFile.getAbsolutePath)
    val parentFilePath: String = new File(this.getClass().getClassLoader().getResource("").getPath()).getParentFile.getAbsolutePath
    val fileName = parentFilePath + System.getProperty("file.separator") + s"result_partition_status_${db}_" + result1.hashCode() + ".txt"
    logger.info("File Name in local is " + fileName)
    val fname: File = new File(fileName)
    FileUtils.deleteQuietly(fname)
    logger.info(fname.getAbsolutePath)
    FileUtils.writeStringToFile(fname, result1)

    //logger.info("Email users configured in application.conf  : " + email)
    //mail -s "$(echo -e 'Job Data Flow Status report from dwh_sdqa   Automated mail pls dont reply\nContent-Type: text/html')"  ram.ghadiyaram@verizon.com  <  /home/hadoop/result_.htm
    val cmd: String = s"mail  -s 'Partition  Status Report for $db   Automated mail pls dont reply!!! \nContent-Type: text/html'  + ram.ghadiyaram@verizon.com < $fname  "
    logger.info("Command being executed is " + cmd)
    executeCommand(cmd)
  }
}