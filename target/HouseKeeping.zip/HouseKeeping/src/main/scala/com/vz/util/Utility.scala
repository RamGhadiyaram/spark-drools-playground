package com.vz.util

import java.io.{BufferedReader, File, InputStreamReader}
import java.sql.{Connection, DriverManager, ResultSet, ResultSetMetaData, Statement, Timestamp}
import java.text.SimpleDateFormat
import java.time.ZoneId
import java.util.{Calendar, Date, TimeZone}

import com.sun.rowset.WebRowSetImpl
import com.typesafe.config.Config
import javax.sql.rowset.WebRowSet
import org.apache.commons.exec.util.StringUtils
import org.apache.commons.io.{FileUtils, FilenameUtils}
import org.apache.commons.lang.WordUtils
import org.apache.commons.lang3.time.DateUtils
import org.apache.hadoop.fs.Path
import org.apache.hadoop.hive.conf.HiveConf
import org.apache.hadoop.hive.conf.HiveConf.ConfVars
import org.joda.time.{DateTime, DateTimeZone, _}
import org.slf4j.LoggerFactory

import scala.collection.JavaConverters._
import scala.util.Try

object Utility {

  val logger = LoggerFactory.getLogger(this.getClass)

  /**
    * getAllCPResources.
    *
    * @param cl ClassLoader
    * @return Array containing all classpath resources.
    */
  def getAllCPResources(cl: ClassLoader): Array[java.net.URL] = cl match {
    case null => Array()
    case u: java.net.URLClassLoader => u.getURLs() ++ getAllCPResources(cl.getParent)
    case _ => getAllCPResources(cl.getParent)
  }

  /**
    * unixTimeStampToDate
    *
    * @param time
    * @return
    */
  def unixTimeStampToDate(time: Long) = {
    val dateTime = new Date(time.asInstanceOf[Long] / 1000)
    import java.text.SimpleDateFormat
    val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val dt = sdf.format(dateTime)
    logger.info(" dateTime : " + dt)
    dt
  }


  /**
    *
    * @param n
    */
  def assess(n: Int) {
    logger.info(
      n compare 10 match {
        case 0 => "ten"
        case 1 => "greater than ten"
        case -1 => "less than ten"
      })
  }

  /**
    * showParts.
    *
    * @param table
    * @param config
    * @param stmt
    */
  def showParts(table: String, config: Config, stmt: Statement): Seq[scala.collection.immutable.Map[String, org.joda.time.DateTime]] = {
    val showPartitionsCmd = " show partitions " + table;
    logger.info("showPartitionsCmd " + showPartitionsCmd)
    try {
      val resultSet = stmt.executeQuery(showPartitionsCmd)

      // checkData(resultSet)
      val result = resultToSeq(resultSet);
      logger.info(s"partitions of $table ->" + showPartitionsCmd + table);
      logger.debug("result " + result)

      result
    }
    catch {
      case e: Exception => logger.error(s"Exception occurred while show partitions table $table..", e)
        null
    }
  }

  /** *
    * checkData.
    *
    * @param queryResult
    */
  def resultToSeq(queryResult: ResultSet) = {
    val md = queryResult.getMetaData

    val colNames = for (i <- 1 to md.getColumnCount) yield md.getColumnName(i)
    var rows = Seq[scala.collection.immutable.Map[String, org.joda.time.DateTime]]()
    while (queryResult.next()) {
      var row = scala.collection.immutable.Map.empty[String, DateTime]
      for (n <- colNames) {
        val str = queryResult.getString(n).split("=")

        //str.foreach(logger.info)
        import org.joda.time.format.DateTimeFormat
        val format = DateTimeFormat.forPattern("yyyy-MM-dd")
        row += str(0) -> DateTime.parse(str(1)) //.toString(DateTimeFormat.shortDate())
        logger.debug(row.toString())
      }
      rows = rows :+ row
    }

    rows
  }

  /**
    * using joda api
    *
    * @param dateStart String
    * @param dateStop  String
    */
  def diffBetweenDatesinMinutes(dateStart: String, dateStop: String) = {
    val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

    //  val dateStop = "2018-04-03 06:34:30"
    //  val dateStart = "2018-04-03 04:45:22.0"
    try {
      val d1 = format.parse(dateStart)
      val d2 = format.parse(dateStop)
      val dt1 = new DateTime(d1)
      val dt2 = new DateTime(d2)
      logger.info(Days.daysBetween(dt1, dt2).getDays() + " days, ");
      logger.info(Hours.hoursBetween(dt1, dt2).getHours() % 24 + " hours, ");
      logger.info(Minutes.minutesBetween(dt1, dt2).getMinutes % 60 + " minutes, ")
      // logger.info(Seconds.secondsBetween(dt1, dt2).getSeconds() % 60 + " seconds.");
    } catch {
      case e: Exception =>
        e.printStackTrace()
    }
  }

  /**
    * getCurrentDateInYMD.
    *
    * @return
    */
  def getCurrentDateInYMD() = {
    val cal = Calendar.getInstance
    val format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    logger.debug(cal.getTime.toString)


    val formatted = format1.format(cal.getTime)
    logger.info(formatted)

    formatted
    //logger.info(format1.parse(formatted))
  }

  /** *
    * checkData.
    *
    * @param rs
    */
  def checkData(rs: ResultSet) = {
    val s: StringBuilder = new StringBuilder
    val metadata = rs.getMetaData
    var i = 0
    while (i < metadata.getColumnCount) {
      s.append("\t" + metadata.getColumnLabel(i + 1))

      {
        i += 1;
        i - 1
      }
    }
    //logger.info("\n--------------------------------------------------------------------")
    s.append("\n--------------------------------------------------------------------\n")
    while (rs.next) {
      var i = 0
      while (i < metadata.getColumnCount) {
        val value = rs.getObject(i + 1)
        if (value == null) s.append("\t       ")
        else {
          s.append("\t" + value.toString.trim)
          i += 1;
          i - 1
        }
      }
      s.append("\n")
    }
    s.append("\n")
    s
  }

  /**
    * @param column   String
    * @param seqOfMap { @see Seq[scala.collection.immutable.Map[String, org.joda.time.DateTime]])}
    *
    *                 usage : val a = Seq(
    *                 Map("businessdate" -> DateTime.parse("2018-03-23T00:00:00.000Z")),
    *                 Map("businessdate" -> DateTime.parse("2018-03-24T00:00:00.000Z")),
    *                 Map("businessdate" -> DateTime.parse("2018-03-22T00:00:00.000Z"))
    *                 )
    *                 *
    *
    *                 // first way
    *                 val mapWithMostRecentBusinessDate = a.sortWith(
    *                 (a, b) => {
    *                 a("businessdate").isAfter(b("businessdate"))
    *                 }
    *                 ).headOption
    *                 *
    *                 // second way
    *                 val mapWithMostRecentBusinessDate1 = a.foldLeft(a.head)((acc, b) => {
    *                 if (b("businessdate").isAfter(acc("businessdate")))
    *                 b
    *                 else
    *                 acc
    *                 })
    */
  def getRecentPartitionDay(column: String, seqOfMap: Seq[scala.collection.immutable.Map[String, org.joda.time.DateTime]]) = {
    // second way
    val mapWithMostRecentBusinessDate1 = seqOfMap.foldLeft(seqOfMap.head)((x, y) => {
      if (y(column).isAfter(x(column)))
        y
      else
        x
    })
  }

  /**
    * getRecentPartitionDate.
    *
    * @param column   String
    * @param seqOfMap { @see Seq[scala.collection.immutable.Map[String, org.joda.time.DateTime]}
    **/
  def getRecentPartitionDate(column: String, seqOfMap: Seq[scala.collection.immutable.Map[String, org.joda.time.DateTime]]): Option[Map[String, DateTime]] = {
    logger.info(" >>>>> column " + column)
    val mapWithMostRecentBusinessDate = seqOfMap.sortWith(
      (a, b) => {
        logger.debug(a(column).toString() + " col2" + b(column).toString())
        a(column).isAfter(b(column))
      }
    )

    logger.debug(s"$getCurrentMethodName mapWithMostRecentBusinessDate: $mapWithMostRecentBusinessDate , \n Head = ${mapWithMostRecentBusinessDate.headOption} ")

    mapWithMostRecentBusinessDate.headOption
  }

  /**
    * convertUtcToTimeZone.
    *
    * @param dateTime
    * @param timeZone
    * @return DateTime
    */
  def convertUtcToTimeZone(dateTime: DateTime, timeZone: String): DateTime = {
    Try(dateTime.withZone {
      logger.info(s"$getCurrentMethodName timeZone passed" + timeZone)
      DateTimeZone.forID(timeZone)
    }).getOrElse(dateTime.withZone(DateTimeZone.forID("Etc/UTC")))
  }

  /** *
    * convertTimeZoneToUtc.
    *
    * @param dateTime
    * @param timeZone
    * @return { @see DateTime}
    */
  def convertTimeZoneToUTC(dateTime: DateTime, timeZone: String): DateTime = {
    Try {
      val zone = DateTimeZone.forID(timeZone)
      val localDateTime = new LocalDateTime(dateTime).toDateTime(zone)
      localDateTime.withZone(DateTimeZone.UTC)
    }.getOrElse(dateTime)
  }

  /**
    * getWebRowSet.
    * just for printing purpose in to XML not much used
    *
    * @param rs
    */
  def getWebRowSet(rs: ResultSet) = {
    val ws: WebRowSet = new WebRowSetImpl();
    ws.populate(rs);
    ws.writeXml(System.out);
  }

  /**
    * accessHiveMetaStore.
    */
  def accessHiveMetaStore() = {
    var conn: java.sql.Connection = null
    try {
      val conf: HiveConf = new HiveConf
      // from outside the cluster i.e. for example emr-spark-dev use hive site xml
      conf.addResource(new Path(s"file:///etc/spark/conf/hive-site.xml"))
      //conf.addResource(new Path(s"file:///home/hadoop/ram/housekeep/conf/hive-site.xml"))
      Class.forName(conf.getVar(ConfVars.METASTORE_CONNECTION_DRIVER))
      Utility.printAllPropsFromHiveSite(conf)

      logger.info("METASTORECONNECTURLKEY ->" + conf.getVar(ConfVars.METASTORECONNECTURLKEY))
      logger.info("METASTORE_CONNECTION_USER_NAME ->" + conf.getVar(ConfVars.METASTORE_CONNECTION_USER_NAME))
      logger.info("METASTOREPWD ->" + conf.getVar(ConfVars.METASTOREPWD))
      conn = DriverManager.getConnection(conf.getVar(ConfVars.METASTORECONNECTURLKEY)
        , conf.getVar(ConfVars.METASTORE_CONNECTION_USER_NAME), conf.getVar(ConfVars.METASTOREPWD))
      val connectionAndConf = (conn, conf)
    } catch {
      case e: Exception =>
        e.printStackTrace()
        logger.info("accessHiveMetaStoreGetConnection error")
        logger.info(e.toString)
        System.exit(-100)
        try (conn.close()) finally {}
        null
    }
  }

  /**
    * resultToHtml
    *
    * @param rs ResultSet
    */


  def resultToHtml(rs: ResultSet) = {
    val md: ResultSetMetaData = rs.getMetaData
    val sb: StringBuilder = new StringBuilder
    val count: Int = md.getColumnCount
    sb.append(
      """
        |<?xml version="1.0" ?>
        |<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitionalt//EN"
        |    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
        |<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
        |<head>
        |  <title>Job Data Flow Status </title>
        |  <style rel="stylesheet" type="text/css">
        |th {
        |  font-weight: bold;
        |  text-align: center;
        |  background-color: #B4B4D9;
        |}
        |
        |td {
        |  padding: 3px;
        |}
        |
        |.odd {
        |  background-color: #B4B4D9;
        |}
        |
        |.even {
        |  background-color: White;
        |}
        |</style>
      """.stripMargin)
    sb.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">")
    sb.append("</head>")

    logger.info("<table style=\"border:1px dotted blue;\">")
    sb.append("<table style=\"border:1px dotted blue;\">")
    print("<tr>")
    sb.append("<tr>")
    var i: Int = 1
    while (i <= count) {
      print("<th>")
      sb.append("<th>" + WordUtils.capitalize(md.getColumnLabel(i))) {
        i += 1;
        i - 1
      }

    }
    logger.info("</tr>")
    sb.append("</tr>")
    var isFirst = true;
    while (rs.next()) {
      if (isFirst == true) {
        sb.append("<tr class=\"even\">")
        isFirst = false
      } else {
        sb.append("<tr class=\"odd\">")
        isFirst = true
      }
      print("<tr>")
      var i: Int = 1
      while (i <= count) {
        sb.append("<td>")
        print("<td>")
        val a = rs.getString(i);
        sb.append(a) {
          i += 1;
          i - 1
        }
        print(a)
      }
      logger.info("</tr>")
      sb.append("</tr>")
    }
    logger.info("</table>")
    sb.append("</table>")
    sb.append("</html>")
  }

  /**
    * executeCommand.
    *
    * @param commandToExecute
    * @return { @see Boolean}
    */
  def executeCommand(commandToExecute: String): Boolean = {
    try {
      val rt = Runtime.getRuntime
      logger.info("process command -- " + commandToExecute);
      val arr = Array("/bin/sh", "-c", commandToExecute)
      val proc = rt.exec(arr)
      logger.info("process started ");
      val exitVal = proc.waitFor
      logger.info(" commandToExecute exited with code: " + exitVal)
      proc.destroy()
    } catch {
      case e: Exception =>
        logger.error("Exception occurred while Launching process : " + e.getMessage)
        return false
    }
    true
  }

  def compareTwoTimeStamps(currentTime: Timestamp, oldTime: Timestamp): Long = {
    val milliseconds1 = oldTime.getTime
    val milliseconds2 = currentTime.getTime
    val diff = milliseconds2 - milliseconds1
    val diffSeconds = diff / 1000
    val diffMinutes = diff / (60 * 1000)
    val diffHours = diff / (60 * 60 * 1000)
    val diffDays = diff / (24 * 60 * 60 * 1000)
    diffMinutes
  }

  /**
    * accessHiveMetaStore.
    */
  def accessHiveMetaStoreGetRef() = {
    var conf: HiveConf = null
    var conn: java.sql.Connection = null
    try {
      conf = new HiveConf
      // from outside the cluster i.e. for example emr-spark-dev use hive site xml
      conf.addResource(new Path(s"file:///etc/spark/conf/hive-site.xml"))
      //conf.addResource(new Path(s"file:///home/hadoop/ram/housekeep/conf/hive-site.xml"))
      Class.forName(conf.getVar(ConfVars.METASTORE_CONNECTION_DRIVER))
      Utility.printAllPropsFromHiveSite(conf)

      logger.info("METASTORECONNECTURLKEY ->" + conf.getVar(ConfVars.METASTORECONNECTURLKEY))
      logger.info("METASTORE_CONNECTION_USER_NAME ->" + conf.getVar(ConfVars.METASTORE_CONNECTION_USER_NAME))
      logger.info("METASTOREPWD ->" + conf.getVar(ConfVars.METASTOREPWD))
      conn = DriverManager.getConnection(conf.getVar(ConfVars.METASTORECONNECTURLKEY)
        , conf.getVar(ConfVars.METASTORE_CONNECTION_USER_NAME), conf.getVar(ConfVars.METASTOREPWD))
      val connectionAndConf = (conn, conf)
      connectionAndConf
    } catch {
      case e: Exception =>
        e.printStackTrace()
        logger.info("accessHiveMetaStoreGetConnection error")
        logger.info(e.toString)
        System.exit(-100)
        try (conn.close()) finally {}
        (conn, conf)
    }
  }

  /**
    * printAllPropsFromHiveSite.
    *
    * @param conf HiveConf
    */
  def printAllPropsFromHiveSite(conf: HiveConf): Unit = {
    val p = conf.getAllProperties
    val scalaProps = p.asScala
    scalaProps foreach (x => logger.info(x._1 + "-->" + x._2))
  }

  /**
    * accessHiveMetaStore.
    */
  def accessHiveMetaStoreGetConnection(): Connection = {
    var conn: java.sql.Connection = null
    try {
      val conf: HiveConf = new HiveConf
      // from outside the cluster i.e. for example emr-spark-dev use hive site xml
      conf.addResource(new Path(s"file:///etc/spark/conf/hive-site.xml"))
      Class.forName(conf.getVar(ConfVars.METASTORE_CONNECTION_DRIVER))
      // Utility.printAllPropsFromHiveSite(conf)

      logger.info("METASTORECONNECTURLKEY ->" + conf.getVar(ConfVars.METASTORECONNECTURLKEY))
      logger.info("METASTORE_CONNECTION_USER_NAME ->" + conf.getVar(ConfVars.METASTORE_CONNECTION_USER_NAME))
      logger.info("METASTOREPWD ->" + conf.getVar(ConfVars.METASTOREPWD))
      conn = DriverManager.getConnection(conf.getVar(ConfVars.METASTORECONNECTURLKEY)
        , conf.getVar(ConfVars.METASTORE_CONNECTION_USER_NAME), conf.getVar(ConfVars.METASTOREPWD))
      conn
    } catch {
      case e: Exception =>
        e.printStackTrace()
        logger.info("accessHiveMetaStoreGetConnection error")
        logger.info(e.toString)
        System.exit(-100)
        try (conn.close()) finally {}
        null
    }
  }

  /**
    * executeProcessScripts
    * <pre>       nohup ./parking_15min_schedule.sh dwh_qa311 qa311_sparkjob.conf "2018-08-30 22:00:00" "2018-08-30 22:30:00"  &
    * //       nohup ./parking_30min_schedule.sh dwh_qa311 qa311_sparkjob.conf "2018-08-30 22:15:00" "2018-08-30 22:30:00" &
    * //       nohup ./parking_hourly_schedule.sh dwh_qa311 qa311_sparkjob.conf "2018-08-30 21:00:00" "2018-08-30 22:00:00"  &
    * </pre> */
  def executeProcessScripts(completePODPath: String): Unit = {
    val completepath = completePODPath + File.separatorChar + "housekeepParking.sh"
    logger.info(getCurrentMethodName + "**CREATING A FILE WHICH WILL CALL ALL PARKING SCRIPTS" + completepath)
    val calendar = getCalendar
    try {

      import org.apache.commons.io.FileUtils
      FileUtils.deleteQuietly(new File(completepath))


      try {
        System.setProperty("user.dir", completePODPath)
        FileUtils.writeStringToFile(new File(completepath), "#!/bin/sh  " + System.getProperty("line.separator"), true)
        FileUtils.writeStringToFile(new File(completepath), "set -x; "  + System.getProperty("line.separator"), true)

        FileUtils.writeStringToFile(new File(completepath), findReportingInterval(15, completePODPath), true)
      } catch {
        case e: Exception =>
          logger.error(getCurrentMethodName + "  execute 15 mins " + e.getCause)
          e.printStackTrace()
      }
      finally {}
      try {
        FileUtils.writeStringToFile(new File(completepath), findReportingInterval(30, completePODPath), true)
      }
      catch {
        case e: Exception =>
          logger.error(getCurrentMethodName + "  execute 30 mins " + e.getCause)
          e.printStackTrace()
      }
      finally {}
      try {
        FileUtils.writeStringToFile(new File(completepath), findReportingInterval(60, completePODPath), true)
        FileUtils.writeStringToFile(new File(completepath),  System.getProperty("line.separator") + " exit 0 ", true)
      } catch {
        case e: Exception =>
          logger.error(getCurrentMethodName + "  execute 60 mins " + e.getCause)
          e.printStackTrace()
      }
      finally {}

    } catch {
      case e: Exception =>
        e.printStackTrace()
    }

  }

  /**
    *findReportingInterval - findthe reporting interval to execute shell script
    * this command will be appended to /home/hadoop/parking/<podname>/script/housekeepParking.sh
    * @param reportIntervalInMin
    * @param completePODPath
    * @return
    */
  def findReportingInterval(reportIntervalInMin: Int, completePODPath: String) = {
    val calendar = java.util.Calendar.getInstance
    val dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
    dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"))
    calendar.setTimeZone(TimeZone.getTimeZone(ZoneId.of("UTC")))
    println(dateFormat.format(calendar.getTimeInMillis))


    calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE) - 25)
    calendar.set(Calendar.SECOND, 0)
    calendar.set(Calendar.MILLISECOND, 0)

    def getEndTime(cal: Calendar, minutesToAdd: Int): String = {
      calendar.add(Calendar.MINUTE, minutesToAdd)
      dateFormat.format(calendar.getTimeInMillis)
    }

    val name = FilenameUtils.getName(new File(completePODPath).getParent)
    val namereplace = s"$name ${name}_sparkjob.conf"
    reportIntervalInMin match {
      case 15 => {
        // 15 minutes
        calendar.get(Calendar.MINUTE) match {
          case x if x <= 15 => {
            calendar.set(Calendar.MINUTE, 0)
          }
          case x if (x > 15 && x <= 30) => {
            calendar.set(Calendar.MINUTE, 15)

          }
          case x if (x > 30 && x <= 45) => {
            calendar.set(Calendar.MINUTE, 30)
          }
          case _ => {
            calendar.set(Calendar.MINUTE, 45)
          }
        }

        val micro = s"  nohup  $completePODPath/parking_15min_schedule.sh $namereplace ${StringUtils.quoteArgument(dateFormat.format(calendar.getTime))}    ${StringUtils.quoteArgument(getEndTime(calendar, reportIntervalInMin))} &"
        logger.info(getCurrentMethodName + micro)
        micro + "\n"
      }
      case 30 => {
        calendar.get(Calendar.MINUTE) match {
          case x if x <= 30 => {
            calendar.set(Calendar.MINUTE, 30)
            calendar.add(Calendar.HOUR_OF_DAY, -1)
          }
          case _ => {
            calendar.set(Calendar.MINUTE, 0)
          }
        }
        val thirtymin = s"  nohup  $completePODPath/parking_30min_schedule.sh $namereplace  ${StringUtils.quoteArgument(dateFormat.format(calendar.getTime))}    ${StringUtils.quoteArgument(getEndTime(calendar, reportIntervalInMin))} & "
        logger.info(getCurrentMethodName + thirtymin)
        thirtymin + "\n"
      }
      case 60 => {
        calendar.add(Calendar.HOUR_OF_DAY, -1)
        calendar.set(Calendar.MINUTE, 0)
        val hourinterval = s"  nohup  $completePODPath/parking_hourly_schedule.sh $namereplace  ${StringUtils.quoteArgument(dateFormat.format(calendar.getTime))}    ${StringUtils.quoteArgument(getEndTime(calendar, reportIntervalInMin))} & "
        logger.info(getCurrentMethodName + hourinterval)
        hourinterval + "\n"
      }
    }

    //s"nohup  $completePODPath/parking_15min.sh dwh_qa311 qa311_sparkjob.conf " +
  }

  /**
    * getCalendar
    *
    * @return java.util.Calendar
    */
  def getCalendar: java.util.Calendar = {
    var calendar = java.util.Calendar.getInstance
    logger.info(calendar.getTime.toString)
    calendar = DateUtils.truncate(calendar, Calendar.HOUR)
    calendar
  }

  /**
    * walkThroughTrees
    * prints the directories in the form of tree
    *
    * @param command
    */

  def walkThroughFSTrees(command: String) = {

    println //Move to the next line to print the next row.

    val process: Process = Runtime.getRuntime.exec(command)
    logger.info(s"$getCurrentMethodName executing command  $command ")
    val stdin = process.getOutputStream();
    val stderr = process.getErrorStream();
    val stdout = process.getInputStream();
    //    // "write" the parms into stdin
    //    line = "param1" + "\n";
    //    stdin.write(line.getBytes() );
    //    stdin.flush();
    //
    //    line = "param2" + "\n";
    //    stdin.write(line.getBytes() );
    //    stdin.flush();
    //
    //    line = "param3" + "\n";
    //    stdin.write(line.getBytes() );
    //    stdin.flush();
    //
    //    stdin.close();
    //
    //    // clean up if any output in stdout
    logger.info(s"$getCurrentMethodName output stream")
    val bufferedReader = new BufferedReader(new InputStreamReader(stdout))
    logger.info(Iterator continually bufferedReader.readLine takeWhile (_ != null) mkString ("\n"))
    logger.info(s" $getCurrentMethodName error stream")
    val bufferedReadererr = new BufferedReader(new InputStreamReader(stderr))
    logger.info(Iterator continually bufferedReadererr.readLine takeWhile (_ != null) mkString ("\n"))
  }

  /**
    * if want to trace and log current method name then the below code will be helpful for you.
    *
    * @return getCurrentMethodName
    */
  def getCurrentMethodName: String = Thread.currentThread.getStackTrace()(2).getMethodName + " -> "

  /**
    * prepareMinEntry
    *
    * @param dateFormat
    * @param interval
    * @param calendar
    * @return java.util.Calendar
    */
  private def prepareMinEntry(dateFormat: SimpleDateFormat, interval: Int, calendar: Calendar, completePODPath: String): java.util.Calendar = {
    val first = dateFormat.format(calendar.getTime)
    calendar.add(Calendar.MINUTE, interval)
    val second = dateFormat.format(calendar.getTime)
    logger.info(getCurrentMethodName + s" nohup  $completePODPath/parking_" + interval + "min_schedule.sh dwh_qa311 qa311_sparkjob.conf "
      + StringUtils.quoteArgument(first) + " " + StringUtils.quoteArgument(second) + " &")
    logger.info(getCurrentMethodName + " 30 minutes ------" + second)
    logger.info(getCurrentMethodName + calendar.getTime.toString)
    calendar
  }
}
