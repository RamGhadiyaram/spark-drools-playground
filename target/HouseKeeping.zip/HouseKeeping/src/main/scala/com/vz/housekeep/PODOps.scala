package com.vz.housekeep

import java.io.File
import java.nio.file.{Files, Path}

import org.apache.commons.io.FileUtils
import org.slf4j.LoggerFactory


/**
  *
  * PODOps.
  * 1) Lookup POD (hive schema) is present in the database.
  * This schema was populated by NEO 4J
  * 2) Create a POD folder structure and symlinks for example
  * <pre>
  * ~/parking1/test/dwh_cicdpersist/
  * └── script
  * ├── client.truststore -> /home/hadoop/client.truststore
  * └── fairscheduler.xml -> /home/hadoop/fairscheduler.xml
  * └──dwh_cicdpersistsparkjob.conf-> /home/hadoop/dwh_cicdpersistsparkjob.conf (this is currently in use not property file)
  * </pre>
  *
  * @author Ram Ghadiyaram
  */
object PODOps extends App with Command {
  val logger = LoggerFactory.getLogger(this.getClass)
  args.foreach(println)
  logger.info("length of args pass to script are " + args.length)
  require(args.length >= 3, " args should NOT be less than 2 \n USAGE : ./runPOD.sh <command Create/Delete> <podname> <podpath>")
  val podName = args(1)
  execute(args)

  /**
    *
    * @param args
    */
  override def execute(args: Array[String]): Unit = {
    args(0).toUpperCase() match {
      case "CREATE" =>
        CreateCommand(args)
      case "DELETE" =>
        DeleteCommand(args)
      case "UPDATE" => ???
      case _ => ???

    }
  }

  /**
    * createSymLinks(podName, podPathWithScript)
    *
    * @param podName           String
    * @param podPathWithScript String
    * @return Path
    */
  def createSymLinks(podName: String, podPathWithScript: String): Path = {
    // 3 sym links below 1) client.truststore  2)fairscheduler.xml  3) property file which is there in /home/hadoop
    FileUtils.deleteQuietly(new File(s"$podPathWithScript/client.truststore"))
    FileUtils.deleteQuietly(new File(s"$podPathWithScript/fairscheduler.xml"))

    Files.createSymbolicLink(new File(s"$podPathWithScript/client.truststore").toPath
      , new File("/home/hadoop/client.truststore").toPath)
    Files.createSymbolicLink(new File(s"$podPathWithScript/fairscheduler.xml").toPath
      , new File("/home/hadoop/fairscheduler.xml").toPath)

    if (podName.contains("_")) { // for example dwh_qa310 then we need to create sym link for qa310sparkjobconfig.properties
      logger.info(s"$podName contains underscore")
      FileUtils.deleteQuietly(new File(s"$podPathWithScript/${podName.split("_")(1)}sparkjobconfig.properties"))
      logger.info("creating POD name SYM LINK " + s"$podPathWithScript/${podName.split("_")(1)}sparkjobconfig.properties ")
      Files.createSymbolicLink(
        new File(s"$podPathWithScript/${podName.split("_")(1)}sparkjobconfig.properties").toPath
        , new File(s"/home/hadoop/${podName.split("_")(1)}sparkjobconfig.properties").toPath)
      /*FileUtils.deleteQuietly(new File(s"$podPathWithScript/${podName}_sparkjob.conf"))
      Files.createSymbolicLink(
        new File(s"$podPathWithScript/${podName}_sparkjob.conf").toPath
        , new File(s"/home/hadoop/${podName}_sparkjob.conf").toPath)*/
    } else { // for example defaultsparkjobconfig.properties
      FileUtils.deleteQuietly(new File(s"$podPathWithScript/${podName}sparkjobconfig.properties"))
      logger.info("POD name doesn't contains UNDERSCORE")
      logger.info("Creating POD name SYM LINK " + s"$podPathWithScript/${podName}sparkjobconfig.properties")
      Files.createSymbolicLink(
        new File(s"$podPathWithScript/${podName}sparkjobconfig.properties").toPath
        , new File(s"/home/hadoop/${podName}sparkjobconfig.properties").toPath)
    }
    FileUtils.deleteQuietly(new File(s"$podPathWithScript/${podName}_sparkjob.conf"))
    Files.createSymbolicLink(
      new File(s"$podPathWithScript/${podName}_sparkjob.conf").toPath
      , new File(s"/home/hadoop/${podName}_sparkjob.conf").toPath)
  }
}