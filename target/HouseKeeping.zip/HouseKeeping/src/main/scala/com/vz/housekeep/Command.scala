package com.vz.housekeep

trait  Command  {
  protected def execute(args: Array[String]) {

  }
}