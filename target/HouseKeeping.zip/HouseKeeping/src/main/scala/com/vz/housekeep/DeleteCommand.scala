package com.vz.housekeep

import java.io.File
import java.sql.{Connection, Statement}

import com.vz.housekeep.PODOps.{logger, podName}
import com.vz.util.Utility
import org.apache.commons.io.FileUtils

case object DeleteCommand {
  def apply(args: Array[String]) {

    logger.info(s" Usage for Delete POD : <Delete> <podname> <podpath>")
    val podPath: String = args(2) + "/" + podName
    logger.info(s"  Delete pod path ${Utility.getCurrentMethodName + podPath} ")
    if (new File(podPath).exists()) {
      FileUtils.deleteQuietly(new File(s"$podPath"))
    }
    val command = s"tree ${podPath}/.. "
    Utility.walkThroughFSTrees(command)
    val commandProcess = s" pstree -apn"
    logger.info(Utility.getCurrentMethodName + commandProcess)
    Utility.walkThroughFSTrees(commandProcess)
    /*val killcommandProcess = s"pkill -f  | grep $podPath"
    logger.info(Utility.getCurrentMethodName + killcommandProcess)
    Utility.walkThroughFSTrees(killcommandProcess)*/

    def deleteDatabase = {
      var conn: Connection = null
      try {
        conn = Utility.accessHiveMetaStoreGetConnection
        logger.info(s"${Utility.getCurrentMethodName} deleting database  $podName")
        val st: Statement = conn.createStatement()
        val isDropped = st.execute(s"drop database $podName cascade")
        logger.info(s"${Utility.getCurrentMethodName} successfully dropped the database $podName ")
      } finally {
        try (conn.close()) finally {}
      }
    }
    //deleteDatabase
  }
}