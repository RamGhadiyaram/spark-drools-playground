package com.vz.housekeep

import java.io.File
import java.sql._

import com.typesafe.config.{Config, ConfigFactory}
import com.vz.util.Utility._
import org.apache.commons.io.FileUtils
import org.joda.time.format.DateTimeFormat
import org.slf4j.LoggerFactory
/**
  *
  * CREATE TABLE HIVE.DWH_SDQA.JOB_DATA_FLOW_STATUS ( jobname varchar, lastupdatedat varchar, status varchar, monitoreddate varchar, startday varchar, comments varchar, issuccess integer COMMENT 'SUCCEES =1 FAILURE =0' ) as ORC
  * drop table JOB_DATA_FLOW_STATUS
  */
object HiveJDBCWatcher { // this is for hive2  jdbc:hive2://localhost:10000/dwh_qastage1"

  val logger = LoggerFactory.getLogger(this.getClass)
  val newLine = sys.props("line.separator")

  /**
    * @param args
    * @throws SQLException
    */
  @throws[SQLException]
  def main(args: scala.Array[String]): Unit = {
    val config: Config = ConfigFactory.defaultApplication()
      .getConfig("jdbc-config.hive")
    config.getConfigList("tableNames").toArray.foreach(println(_))

    logger.error(config.toString)
    val username: String = config.getString("username")
    val password: String = config.getString("password")
    val driverClass = config.getString("driverClassName")
    val url: String = config.getString("url")
    val database: String = config.getString("database")

    getAllCPResources(this.getClass.getClassLoader).foreach(r => logger.debug("URL under CP : " + r.toString))

    try {
      logger.info(s"driver class is " + driverClass)
      Class.forName(driverClass)
    }
    catch {
      case e: ClassNotFoundException =>
        logger.error(e.toString)
        System.exit(1)
    }
    //replace "hive" here with the name of the user the queries should run as
    logger.info(s"url + database ${url + database}, username : {$username}, password {$password}")
    val con = DriverManager.getConnection(url + database, username, password)
    val stmt = con.createStatement

    /*set hive.support.concurrency=true
    set hive.enforce.bucketing=true
    set hive.exec.dynamic.partition.mode=nonstrict
    set hive.txn.manager=org.apache.hadoop.hive.ql.lockmgr.DbTxnManager
    set hive.compactor.initiator.on = true
    set hive.compactor.worker.threads = 10*/


    val sqlTruncate = config.getString("truncateCmd");
    try {
      logger.info("truncating table JOB_DATA_FLOW_STATUS ->" + sqlTruncate);
      stmt.execute(sqlTruncate);
    }
    catch {
      case e: Exception => logger.error("Exception occurred while truncated table JOB_DATA_FLOW_STATUS..")
    }

    val sqlStatementcreate = config.getString("createjobdataflowstatus");
    try {
      logger.info(sqlStatementcreate)
      stmt.execute(sqlStatementcreate);
      logger.info(s"created table : $sqlStatementcreate");
    }
    catch {
      case e: Exception => logger.error("Exception occurred when creating.." + sqlStatementcreate)
    }
    logger.info(config.getConfigList("tableNames").toString)
    try {
      config.getConfigList("tableNames").toArray().foreach(
        tableName => {
          logger.info(tableName.getClass.getName)

          populateJobDataFlowStatusWithConfig(tableName.asInstanceOf[Config], con, stmt)

        }
      )
      val sqlStatementSelect = " SELECT jobname as `Job Name` , lastupdatedat as `LastTime Tables Were Updated` , status as Status , monitoreddate as `Monitored Date`,comments as Comments from JOB_DATA_FLOW_STATUS  ";
      logger.info(sqlStatementSelect)
      // Execute SELECT Query
      val res = stmt.executeQuery(sqlStatementSelect);
      logger.info(System.getProperty("user.home"))

      //val result = checkData(res)
      //  println(result.toString)
      val result1 = resultToHtml(res).toString
      logger.info(result1)
      logger.info("this.getClass().getClassLoader().getResource(\"\").getPath()" + new File(this.getClass().getClassLoader().getResource("").getPath()).getParentFile.getAbsolutePath)
      val parentFilePath: String = new File(this.getClass().getClassLoader().getResource("").getPath()).getParentFile.getAbsolutePath
      val fileName = parentFilePath + System.getProperty("file.separator") + "result_" + result1.hashCode() + ".htm"
      logger.info("File Name in local is " + fileName)
      val fname: File = new File(fileName)
      FileUtils.deleteQuietly(fname)
      logger.info(fname.getAbsolutePath)
      FileUtils.writeStringToFile(fname, result1)
      val email = config.getString("emailusers")
      logger.info("Email users configured in application.conf  : " + email)
      //mail -s "$(echo -e 'Job Data Flow Status report from dwh_sdqa   Automated mail pls dont reply\nContent-Type: text/html')"  ram.ghadiyaram@verizon.com  <  /home/hadoop/result_.htm
      val cmd: String = s"mail  -s 'Job Data Flow Status Report for $database   Automated mail pls dont reply!!! \nContent-Type: text/html'  + $email < $fname  "
      logger.info("Command being executed is " + cmd)
      executeCommand(cmd)
      //  path = StringUtils.join(pathParts, File.separator);
      if (res != null) res.close()
      logger.info(sqlStatementSelect + ": OK");
    } finally {
      try {
        if (con != null) con.close()
        if (stmt != null) stmt.close()
      } catch {
        case e: Exception => logger.error("Exception occurred when closing the connection")
      }
    }
  }

  /**
    * populateJobDataFlowStatus.
    *
    * @param tableConfig
    * @param con
    *
    */
  def populateJobDataFlowStatusWithConfig(tableConfig: Config, con: Connection, stmt: Statement) = {
    var res: ResultSet = null
    var sql = ""
    val dtfOut = DateTimeFormat.forPattern("yyyy-MM-dd")

    /**
      * describeTable.
      */
    def describeTable = {
      // show tables
      sql = "describe " + tableConfig.getString("table")
      logger.info("describe  ..." + sql)
      res = stmt.executeQuery(sql)
      while (res.next) {
        logger.info(res.getString(1) + "\t" + res.getString(2));
      }
    }

    try {
      val table: String = tableConfig.getString("table")
      val column: String = tableConfig.getString("column")
      val partitionColumn = tableConfig.getString("partitionColumn")
      val threshholdIntervalForCheck = tableConfig.getLong("intervalInMinutes")
      val message: String = tableConfig.getString("message")
      val jobname: String = tableConfig.getString("jobname")
      logger.info(s"table : $table column : $column interval : $threshholdIntervalForCheck message : $message jobName : $jobname ")
      val seqOfRows = showParts(table, tableConfig, stmt)
      val recentParts = getRecentPartitionDate(partitionColumn, seqOfRows)
      if (recentParts.isEmpty) {
        logger.error(s"$newLine $newLine NO PARTITIONS FOUND FOR THIS TABLE $table")
        insertIntoJobDataFlowStatus(stmt, jobname, "-1", "NA", 0, "NO Data", s"No Data found for this table $table")
      } else {
        val partitionColumnVal = recentParts.get(s"$partitionColumn")
        val partitionColumnValue = dtfOut.print(partitionColumnVal)
        logger.debug("classname is " + partitionColumnVal.getClass.getName)

        logger.debug(seqOfRows.toString)
        logger.info(s"recent partition date $partitionColumnVal ")
        if (logger.isDebugEnabled()) {
          describeTable
        }

        var lastupddate = ""
        var startday = getCurrentDateInYMD

        /**
          * getLastUpdatedTableTime.
          *
          * @return startday
          */
        def getLastUpdatedTableTime: Unit = {
          // regular hive query
          //sql = s" select from_unixtime(cast(max(since)/1000000 as bigint ) ) from    $tableName "
          sql = s" select max($column ) from  $table where $column is not null and $partitionColumn = '$partitionColumnValue' "
          logger.info("Running: " + sql)
          res = stmt.executeQuery(sql)


          while (res.next) {
            lastupddate = res.getString(1)
            logger.info("last updated on  " + lastupddate + "  job started date" + startday)
          }

        }

        getLastUpdatedTableTime
        if (lastupddate.contains("-")) {
          lastupddate = (convertStringToTimestamp(lastupddate) * 1000).toString
          logger.info("after converting to timestamp " + lastupddate)
        }
        val (currenttimestamp: Long, differenceInMinutes: Long) = diffInMinutes(lastupddate)
        var isSuccess = 0 //  This column only for reporting purpose no significance.
        val status = differenceInMinutes match {
          case x if x > threshholdIntervalForCheck => {
            logger.info(differenceInMinutes + " less than " + threshholdIntervalForCheck);
            "Fail"
          }
          case _ => {
            logger.info(differenceInMinutes + "greater or equal than " + threshholdIntervalForCheck);
            isSuccess = 1
            "Success"
          }
        }

        val remarks = status match {
          case "Fail" => {
            s"current($currenttimestamp) - lastupdated(${(lastupddate.toLong / 1000)}) " +
              s"i.e. $differenceInMinutes >$threshholdIntervalForCheck mins (Monitored Interval) = Possible Job failure check the logs and job ui"
          }
          case _ => {
            s" current - lastupdated date : $differenceInMinutes ..(Threshhold configured : $threshholdIntervalForCheck) Wait Until next table monitor run of $table.."
          }
        }
        insertIntoJobDataFlowStatus(stmt, jobname, lastupddate, startday, isSuccess, status, remarks)
      }


    } catch {
      case e: Exception =>
        logger.error(s"Exception Occurred  ${e.toString}", e)
    } finally {
      logger.info("Closing all resources opened....")
      try {
        if (res != null) res.close()
      } catch {
        case e: Exception => logger.error("Exception occurred when closing the statement and result")
      }
    }
  }
  import java.text.SimpleDateFormat

  /**
    *
    * @param str_date
    * @return
    */
  def convertStringToTimestamp(str_date: String): Long = try {
    val formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
    val date = formatter.parse(str_date)
    logger.info("convertStringToTimestamp " + date.getTime)
    date.getTime
    //return timeStampDate;
  } catch {
    case e: Exception =>
      e.printStackTrace(System.out)
      -1
  }
  /**
    * diffInMinutes.
    *
    * @param lastupddate
    * @return (currenttimestamp, differenceInMinutes)
    */
  private def diffInMinutes(lastupddate: String) = {
    val currenttimestamp: Long = System.currentTimeMillis
    val diff = (currenttimestamp - (lastupddate.toLong / 1000))
    val differenceInMinutes = diff / (60 * 1000)
    (currenttimestamp, differenceInMinutes)
  }

  /**
    * insertIntoJobDataFlowStatus.
    *
    * @param stmt
    * @param jobname
    * @param lastupddate
    * @param startday
    * @param isSuccess
    * @param status
    * @param remarks
    */
  private def insertIntoJobDataFlowStatus(stmt: Statement, jobname: String, lastupddate: String, startday: String, isSuccess: Int, status: String, remarks: String) = {
    val sqlStatementInsert =
      s"""
         | INSERT INTO JOB_DATA_FLOW_STATUS VALUES
         |  ( '${(jobname)}'
         |  , '${unixTimeStampToDate(lastupddate.toLong)}'
         |   , '$status'
         |   , '${getCurrentDateInYMD}'
         |   , '$startday'
         |    ,'$remarks' ,
         |     $isSuccess  )
      """.stripMargin
    logger.info("  ----->     " + sqlStatementInsert)
    // Execute INSERT Query
    val isInserted = stmt.execute(sqlStatementInsert);

    logger.info(" isInserted " + isInserted)
  }
}
