
package com.vz.housekeep;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
import java.net.*;

public class HiveJdbcClient {
    // this is for hive2  jdbc:hive2://localhost:10000/dwh_qastage1"
    private static String driverName = "org.apache.hive.jdbc.HiveDriver";
    // this is for hive 1  jdbc:hive://localhost:10000/dwh_qastage1"
    private static String driverName1 = "org.apache.hadoop.hive.jdbc.HiveDriver";

    /**
     * @param args
     * @throws SQLException
     */
    public static void main(String[] args) throws SQLException {
/*
ClassLoader cl = HiveJdbcClient.class.getClassLoader();
        URL[] urls = ((URLClassLoader)cl).getURLs();
        for(URL url: urls){
            System.out.println(url.getFile());
        }
*/
        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.exit(1);
        }
        //replace "hive" here with the name of the user the queries should run as
        Connection con = DriverManager.getConnection("jdbc:hive2://localhost:10000/dwh_qastage1", "hadoop", "hadoop");
        Statement stmt = con.createStatement();
        ResultSet res = null;
        try {
            String tableName = "testHiveDriverTable";
            stmt.execute("drop table if exists " + tableName);//DROP TABLE IF EXISTS
            System.out.println("drop table if exists " + tableName + " was  done");
            stmt.execute("create table " + tableName + " (key int, value string)");
            System.out.println("Create table " + tableName + " was done");
            System.out.println("Connection/Statement created");
            tableName = "fs_aggregation_traffic_events";
            // show tables
            String sql = "show tables '*'";
            System.out.println("show tables executing....");
            System.out.println("Running: " + sql);
            res = stmt.executeQuery(sql);
            while (res.next()) {
                System.out.println(res.getString(1));
            }
            // describe table
            //    sql = "describe " + tableName;
            //   System.out.println("Running: " + sql);
            //  res = stmt.executeQuery(sql);
            // while (res.next()) {
            //   System.out.println(res.getString(1) + "\t" + res.getString(2));
            //}


            // regular hive query
            sql = "select * from " + tableName + " limit 1";
            System.out.println("Running: " + sql);
            res = stmt.executeQuery(sql);
            while (res.next()) {
                System.out.println(res.getString(1));
            }
        } catch (Exception e) {
            System.out.println("exception occured" + e.toString());
        } finally {
            System.out.println("Closing all resources opened....");
            try {
                con.close();
                stmt.close();
                res.close();
            }
            catch (Exception e) {}
        }
    }
}
